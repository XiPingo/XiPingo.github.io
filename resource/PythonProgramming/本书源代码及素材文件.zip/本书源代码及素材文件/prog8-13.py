# -*- coding: utf-8 -*-
"""
@author: NJU_Taoye
"""
class PersonInfo:
    '''define PersonInfo Class'''   
    def __init__(self, dep): 
        self.dep = dep
        self.num = 0
        self.plist = []
    def insertp(self, name, age):
        for x in self.plist:
          if name in x:
              print("{0} already in list".format(name))
              return False
        self.num += 1
        self.plist.append([name,age])
        return True      
    def delp(self,name):
        for x in self.plist:
            if name in x:
                print("Delete {0}".format(name))
                self.plist.remove(x)
                self.num -= 1
                return True
        print("{0} not in list".format(name))
        return False      
    def searchp(self,name):
        for x in self.plist:
            if name in x:
                print("{0} in list".format(name))
                print(x)
                return True
        print("{0} not in list".format(name))   
        return False 
    def printplist(self):
        for x in self.plist:
            print(x)
    def __add__(self,obj):
        if self.dep != obj.dep:
            print("The names of the two departments are different.")
            return
        if self.__class__ != obj.__class__:  # obj.__class__为实例obj所属的类
            print("The classes of the two instances are different.")
            return
        t = self.__class__(self.dep) 
        t.num = self.num      
        for i in self.plist:
            t.plist.append(i)
        for i in obj.plist:
            flg = 1          
            for x in self.plist:
                if i[0] in x:
                    flg = 0
                    break
            if flg == 1:
                t.num += 1
                t.plist.append(i)
        return t

if __name__ == '__main__':
    x = PersonInfo('CS')
    x.insertp('WangTian', 18)
    x.insertp('ZhangWei', 20)
    y = PersonInfo('CS')
    y.insertp('LiHua', 19)
    y.insertp('ZhangWei', 20)
    x.printplist()
    y.printplist()
    z = x + y
    if isinstance(z,PersonInfo):    # 判断z是不是PersonInfo的子类
        print("There are {0} people in Dep.{1}".format(z.num,z.dep)) 
        z.printplist()

