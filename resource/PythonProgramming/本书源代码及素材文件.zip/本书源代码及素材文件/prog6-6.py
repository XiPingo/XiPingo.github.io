# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
def findNumFriends(s):
    s = s.split(',')
    d = {}
    for num in s: 
        sumNum = sum(map(int, num))
        d[sumNum] = d.get(sumNum, []) + [num]
    lst = sorted(d.items())
    result = map(sorted, [x[1] for x in lst])
    return result

if __name__ == "__main__":
    s = input("Enter the numbers: ")
    result = findNumFriends(s)
    for item in result:
        print(item)
