# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
def moveSubstr(s, flag, n):
    if n > len(s):
        return -1
    else:
        if flag == 1:
            return s[n:] + s[:n]
        else:
            return s[-n:]+ s[:-n]

if __name__ == "__main__":
    s, flag, n = input("Enter the 'string,flag,n': ").split(',')
    result = moveSubstr(s, int(flag), int(n))
    if result != -1:
        print(result)
    else:
        print('The n is too large')
