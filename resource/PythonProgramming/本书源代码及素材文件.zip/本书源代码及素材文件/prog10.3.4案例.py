# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
import pandas as pd

# 读取数据，假设将数据读取后处理成一个DataFrame对象df
data = '''用户id,时间,用户点击的课程id
A,2020-0101-21:30:12,1001
A,2020-0101-21:31:16,1002
A,2020-0102-08:20:31,1003
B,2020-0622-22:20:00,1002
B,2020-1001-22:20:32,1002
B,2020-1001-22:22:31,1002
B,2020-1001-22:22:32,1003
C,2020-1001-23:20:31,1001
C,2020-1005-20:22:00,1002'''
data = data.split('\n')
columns = data[0].split(',')
data_temp = [line.split(',') for line in data[1:]]
df = pd.DataFrame(data_temp, columns = columns)
# (1)
this_format = '%Y-%m%d-%H:%M:%S'
df['format_time'] = pd.to_datetime(df['时间'], format = this_format)
df['hour'] = df['format_time'].dt.hour
hour_count = df['hour'].value_counts()
# (2)
sorted_hour_count = hour_count.reindex(range(0, 24)).fillna(0)
print(sorted_hour_count)
# (3)
year_range = df['format_time'].dt.year == 2020
month_range = (df['format_time'].dt.month >= 1) & (df['format_time'].dt.month <= 6)
df_valid = df.loc[year_range & month_range]
month1_6_count = df_valid['format_time'].dt.month.value_counts()
sorted_month1_6_count = month1_6_count.reindex(range(1, 7)).fillna(0)
print(sorted_month1_6_count)
# (4)
df['hour'] = df['format_time'].dt.hour
course_hour_count = df.groupby(['用户点击的课程id', 'hour']).count()
print(course_hour_count)

time_interval = df['format_time'].diff()
time_interval_seconds =  time_interval.dt.total_seconds().copy()
author_first_appear = ~df['用户id'].duplicated(keep = 'first')  # ~用于取反
time_interval_seconds[author_first_appear] = 0
print(time_interval_seconds)



