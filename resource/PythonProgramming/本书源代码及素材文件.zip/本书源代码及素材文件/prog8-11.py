# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
class Dog(object):
    "define Dog class"
    counter = 0
    def __init__(self, name):
        self.name = name
        Dog.counter += 1
    def greet(self):
        print("Hi, I am  {:s}, my number is {:d}.".format(self.name, Dog.counter))

class BarkingDog (Dog):
    "define subclass BarkingDog"
    def __init__(self, name, color):
        super().__init__(name)
        self.color = color
    def greet(self):
        "initial subclass"
        print("Woof! I am {:s} {:s}, my number is {:d}.".format(self.color, self.name, Dog.counter))
    
if __name__ == '__main__':
    x = BarkingDog("Zoe", "black")
    x.greet()