# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
import random

with open('random.txt', 'w+') as fp:
    for i in range(500):
         fp.write(str(random.randint(1, 100)))
         fp.write('\n')
    fp.seek(0)
    nums = fp.readlines()
	
nums = [num.strip() for num in nums]
setNums = set(nums)
lst = [0] * 101
for num in setNums:
    c = nums.count(num)
    lst[int(num)] = c
for i in range(len(lst)):
    if lst[i] == max(lst):
        print(i)
