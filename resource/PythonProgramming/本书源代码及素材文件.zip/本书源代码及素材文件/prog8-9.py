# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
class Dog(object):
    "define Dog class"
    counter = 0
    def __init__(self, name):
        self.name = name
        Dog.counter += 1
    def greet(self):
        print("Hi, I am {:s}, my number is {:d}.".format(self.name, Dog.counter))
class BarkingDog(Dog):
    "define subclass BarkingDog"
    def bark(self):
        print("barking")

if __name__ == '__main__':
    dog = BarkingDog("Zoe")
    dog.greet()
    dog.bark()

