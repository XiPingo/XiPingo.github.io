# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
from math import sqrt

def isprime(x):
    ''' prime judgement '''
    if x == 1: 
        return False
    if x % 2 == 0:
        return x == 2
    k = int(sqrt(x))
    for j in range(3, k+1, 2): 
        if x % j == 0:
            return False 
    return True
    
if __name__ == "__main__":		# name和main前后各有两条下划线
    for i in range(1, 101):    
        if isprime(i):
            print(i, end = ' ')
