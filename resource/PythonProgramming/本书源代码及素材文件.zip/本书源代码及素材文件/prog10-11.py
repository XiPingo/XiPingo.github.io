# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
import matplotlib as mpl
import numpy as np
import matplotlib.pyplot as plt

mpl.rcParams['font.sans-serif'] = ['SimHei']   # 解决中文标签不能正确显示的问题
mpl.rcParams['axes.unicode_minus'] = False    # 解决负号不能正确显示的问题

N = 5
ind = np.arange(N)
stu_counts1 = np.array([15, 13, 8, 10, 4])
stu_counts2 = np.array([18, 12, 11, 4, 6])
plt.bar(ind, stu_counts1, label = '班级1')
plt.bar(ind, stu_counts2, bottom = stu_counts1, label = '班级2')
plt.title('两班成绩对比')
plt.xlabel('等级')
plt.ylabel('数量')
plt.xticks(ind, ('A', 'B', 'C', 'D', 'E'))     # 设置X轴的刻度标签
plt.yticks(np.arange(0, 41, 5))     # 设置Y轴的刻度
plt.legend(loc = 'best')
plt.show()

