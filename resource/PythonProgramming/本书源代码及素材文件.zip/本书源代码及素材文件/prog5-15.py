# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
from math import sqrt 

count = 0
for i in range(2, 101):
    flag = True
    k = int(sqrt(i))
    for j in range(2, k+1):
        if i % j == 0:
            flag = False
            break
    if flag:
        count += 1
        if count % 5 == 0:
            print(i, end = '\n')
        else:
            print(i, end = ' ')
