import jieba
from imageio import imread
from wordcloud import WordCloud
import matplotlib.pyplot as plt

with open('sea.txt', encoding='utf8') as f:
    data = f.read()
    
words_ori = list(jieba.cut(data))
stop_words = set(line.strip() for line in open('stopwords.txt', encoding='utf-8'))
words = [word for word in words_ori if word not in stop_words]

mask_image = imread("mickey.png")
Wc = WordCloud(
        font_path='simhei.ttf',
        background_color='white',
        mask=mask_image,
        colormap='Oranges',
        max_words=10)
s = Wc.generate(' '.join(words))
plt.imshow(s)
