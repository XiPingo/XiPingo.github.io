# -*- coding: utf-8 -*-
"""
@author: NJU_Taoye
"""
class PersonInfo:
    '''define PersonInfo Class'''   
    def __init__(self, dep): 
        self.dep = dep
        self.num = 0
        self.plist = []
    def insertp(self, name, age):
        for x in self.plist:
          if name in x:
              print("{0} already in list".format(name))
              return False
        self.num += 1
        self.plist.append([name,age])
        return True      
    def delp(self,name):
        for x in self.plist[:]:
            if name in x:
                print("Delete {0}".format(name))
                self.plist.remove(x)
                self.num -= 1
                return True
        print("{0} not in list".format(name))
        return False      
    def searchp(self,name):
        for x in self.plist:
            if name in x:
                print("{0} in list".format(name))
                print(x)
                return True
        print("{0} not in list".format(name))   
        return False 
    def printplist(self):
        for x in self.plist:
            print(x)

class StuInfo(PersonInfo):
    def insertp(self,name,age,no,origin):
        for x in self.plist:
            if name in x:
                print("{0} already in list".format(name))
                return False
        self.num += 1
        self.plist.append([name,age,no,origin])
        return True     

if __name__ == '__main__':
    csstu=StuInfo('CS')
    csstu.insertp('WangTian',18,10001,'JS')
    csstu.insertp('ZhangWei',20,10002,'BJ')
    csstu.insertp('LiHua',19,10003,'ZJ')
    print("There are {0} students in Dep.{1}".format(csstu.num,csstu.dep))
    csstu.printplist()
    csstu.searchp('LiJianGuo')
    csstu.delp('ZhangWei')
    csstu.printplist()
