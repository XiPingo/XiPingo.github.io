# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
from random import randint

x = randint(0, 300)
go = 'y'

while go == 'y':
    digit = int(input('Please enter a number between 0~300: '))
    if digit  == x:
        print('Bingo!')
        break
    elif digit > x:
        print('Too large, please try again.')
    else:
        print('Too small, please try again.')    
    go = input('Enter y if you want to continue: ')
else:
    print('I quit and byebye!')