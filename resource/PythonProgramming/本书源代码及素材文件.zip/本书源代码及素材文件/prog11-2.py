# -*- coding: utf-8 -*-
"""
@author: NJU_Zhangli
"""
import requests
from bs4 import BeautifulSoup
import re

headers = {'User-Agent': 'Mozilla/5.0 (Macintosh: Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko)  Chrome/71.0.3578.98 Safari/537.36'}
r = requests.get('https://book.douban.com/subject/1084336/comments/', headers = headers)
soup = BeautifulSoup(r.text, 'lxml')
pattern = re.compile('<span class="user-stars allstar(.*?) rating"')
p = re.findall(pattern, r.text)
lst = []
for star in p:
    lst.append(int(star))
print(lst)
 
 
